from flask import Flask, request, jsonify, send_from_directory
import os
import base64

app = Flask(__name__)

# Путь, по которому будет сохраняться архив
SAVE_DIRECTORY = 'received_archives'
if not os.path.exists(SAVE_DIRECTORY):
    os.makedirs(SAVE_DIRECTORY)

@app.route('/check', methods=['GET'])
def check_connection():
    # Этот маршрут будет проверять соединение
    if request.args.get('reason') == 'heartbeat':
        return 'flag{1_w4n7_y0u_b4ck', 200
    return '', 400  # Возвращать 400, если параметр неверный

@app.route('/collection', methods=['POST'])
def collect_archive():
    # Этот маршрут будет обрабатывать архив
    if request.method == 'POST':
        archive_data = request.form.get('archive')

        if archive_data:
            # Декодируем данные из Base64
            archive_bytes = base64.b64decode(archive_data)
            
            # Генерируем уникальное имя файла
            archive_count = len(os.listdir(SAVE_DIRECTORY))
            file_path = os.path.join(SAVE_DIRECTORY, f'archive_{archive_count + 1}.zip')
            with open(file_path, 'wb') as f:
                f.write(archive_bytes)

            return jsonify({'message': 'Archive received successfully! Check it on /archives_513426d0-854a-44db-9abc-b8c24c70786b'}), 201
        return jsonify({'error': 'No archive found in the request!'}), 400

@app.route('/archives_513426d0-854a-44db-9abc-b8c24c70786b', methods=['GET'])
def list_archives():
    # Этот маршрут будет возвращать список загруженных архивов
    archives = os.listdir(SAVE_DIRECTORY)
    return jsonify({'archives': archives}), 200

@app.route('/archives_513426d0-854a-44db-9abc-b8c24c70786b/<filename>', methods=['GET'])
def download_archive(filename):
    # Этот маршрут будет отправлять архив на скачивание
    return send_from_directory(SAVE_DIRECTORY, filename, as_attachment=True), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
