from random import randint, shuffle
from Cryptodome.Util.number import bytes_to_long

flag = b'flag{??????????????????}'

def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def getKey(len_block):
    A = [0] * len_block
    s = 0
    for i in range(len_block):
        A[i] = randint(s + 1, s + (1 << 32))
        s += A[i]
    n = randint(s + 1, s + (1 << 32))
    t = randint(2, n)
    while gcd(n, t) != 1:
        t = randint(2, n)
    B = [(t * a) % n for a in A]
    Pi = [i for i in range(0, len_block)]
    shuffle(Pi)
    B = [B[Pi[i]] for i in range(len_block)]
    u = pow(t, -1, n)
    Pi_1 = [0] * len(Pi)
    for i in range(len(Pi)):
        Pi_1[Pi[i]] = i
    return B, A, u, n, Pi_1

def encrypt_block(block, B):
    return sum([B[i] if block & (1 << (len(B) - i - 1)) else 0 for i in range(len(B))])

def encrypt(m, B):
    len_bloks = m.bit_length() // len(B)
    len_bloks += 1 if m.bit_length() % len(B) else 0
    blocks = [(m >> (i * len(B))) & ((1 << len(B)) - 1) for i in range(len_bloks)]
    return [encrypt_block(block, B) for block in blocks]

def decrypt_block(block, A, u, n, Pi):
    c = (block * u) % n
    m = 0
    for i in range(len(A) - 1, -1, -1):
        if c >= A[i]:
            m ^= 1 << (len(A) - Pi[i] -1)
            c -= A[i]
    return m

def decrypt(c, A, u, n, Pi):
    m_bloks = [decrypt_block(block, A, u, n, Pi) for block in c]
    m = 0
    for i in range(len(m_bloks)):
        m ^= m_bloks[i] << (len(A)*i)
    return m
    
def main():
    B, A, u, n, Pi = getKey(64)
    print(f"B = {B}")
    print(f"C = {encrypt(bytes_to_long(flag), B)}")

if __name__ == "__main__":
    main()
