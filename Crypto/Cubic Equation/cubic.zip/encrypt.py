from Cryptodome.Util.number import bytes_to_long
from os import urandom

p = 0x19a65c04a61ae5d64265afa9cfb2dbe931054969b4aeb872cae33a1b043865369
flag = b'flag{??????????}'
flag += urandom(32 - len(flag))

def hesh(x):
    return (89*pow(x, 3, p) + 4*pow(x, 2, p) + 3*x + 7) % p

def main():
    x = bytes_to_long(flag)
    print(y = hex(hesh(x)))

if __name__ == "__main__":
    main()
