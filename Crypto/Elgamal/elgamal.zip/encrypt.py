from elliptical_curve import Elliptical_Curve, Point
from random import randint
from Cryptodome.Util.number import bytes_to_long

flag = b'flag{???????}'
p = 310717010502520989590157367261876774703
a = 2
b = 3
E = Elliptical_Curve(a, b, p)
G = E.get_Gen()
print(f'G = {G}')

def getKey():
    u = randint(2, p - 2)
    D = u*G
    return u, D

def encrypt(m, D):
    k = randint(2, p - 2)
    R = k*G
    P = k*D
    c = (m * (P.x)) % p
    return c, R

def main():
    u, D = getKey()
    print(f'D = {D}')
    c, R = encrypt(bytes_to_long(flag), D)
    print(f'c = {c}\nR = {R}')

if __name__ == "__main__":
    main()


