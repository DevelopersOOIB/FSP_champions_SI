from Cryptodome.Util.number import getPrime, long_to_bytes, bytes_to_long
from hashlib import sha256
from random import randint

flag = b'flag{?????????????????????????}'

def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def getKey(len_key):
    p, q = getPrime((len_key >> 1) + 1), getPrime((len_key >> 1) + 1)
    n = p*q
    fi = (p - 1) * (q - 1)
    e = randint(3, 256)
    while gcd(fi, e) != 1:
        e = randint(0, 256)
    d = pow(e, -1, fi)
    g = ?        
    return e, d, n, g

def sign(g, n, text):
    return sha256(long_to_bytes(pow(g, bytes_to_long(sha256(text).digest()), n))).digest()

def main():
    e, d, n, g = getKey(2024)
    print(f'n = {n}\n' + \
          f'e = {e}\n' + \
          f'g = {g}')
    m1 = bytes_to_long(flag)
    c1 = pow(m1, e, n)
    h = sign(g, n, flag)
    m2 = bytes_to_long(flag + h)
    c2 = pow(m2, e, n)
    print(f'encrypted flag: {c1}')
    print(f'encrypted flag with signature: {c2}')

if __name__ == "__main__":
    main()
