from secret import random

flag = b'flag{random_????????????????????}'

def encrypt(text):
    return bytes([t ^ random() for t in text])

def main():
    with open('output.txt', 'wb') as file:
        file.write(encrypt(flag))

if __name__ == "__main__":
    main()
