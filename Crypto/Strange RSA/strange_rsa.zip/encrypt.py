from Cryptodome.Util.number import getPrime, bytes_to_long
from random import randint

flag = b'flag{?????????????????????}'

def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def getKey(len_key):
    p, q = getPrime((len_key >> 1) + 1), getPrime((len_key >> 1) + 1)
    n = p * q
    fi = (p - 57) * (q - 57)
    e = randint(2, 1 << 400)
    while gcd(e, fi) != 1:
        e = randint(2, 1 << 400)
    d = pow(e, -1, fi)
    return n, e, d

def main():
    n, e, d = getKey(2048)
    c = pow(bytes_to_long(flag), d, n)
    print(f'n = {n}\nd = {d}\nc = {c}')

if __name__ == "__main__":
    main()
