from random import randint, shuffle

flag = 'flag??????????????????????'
Alf = [chr(a) for a in range(ord('a'), ord('z') + 1)]
len_blok = ?

def pad(text, len_blok):
    num = len_blok - len(text) % len_blok
    return text + Alf[num]*num

def encrypt_1(text, key):
    ctext = [text[key[i]::len(key)] for i in range(len(key))]
    return ''.join([''.join([ctext[j][i] for j in range(len(key))]) for i in range(len(text) // len(key))])

def encrypt_2(text, key):
    ctext = [Alf[(Alf.index(text[i]) + key[i % len(key)]) % len(Alf)] for i in range(len(text))]
    return ''.join(ctext)

def gen_key(len_blok):
    key1 = [i for i in range(len_blok)]
    shuffle(key1)
    key2 = [randint(0, len(Alf) - 1) for _ in range(len_blok)]
    return key1, key2

def main():
    with open('text.txt', 'r') as file:
        text = file.read()
    key1, key2 = gen_key(len_blok)
    text = pad(text + flag, len_blok)
    ctext = encrypt_1(encrypt_2(text, key2), key1)
    with open('text.txt.enc', 'w') as file:
        file.write(ctext)

if __name__ == "__main__":
    main()
